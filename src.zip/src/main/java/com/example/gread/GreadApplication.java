package com.example.gread;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GreadApplication {

    public static void main(String[] args) {
        SpringApplication.run(GreadApplication.class, args);
    }
}
