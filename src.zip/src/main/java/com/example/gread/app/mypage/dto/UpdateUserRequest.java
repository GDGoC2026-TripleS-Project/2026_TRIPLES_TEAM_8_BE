package com.example.gread.app.mypage.dto;

import lombok.Data;

@Data
public class UpdateUserRequest {
    private String nickname;
}
