package com.example.gread.app.review.domain;

public enum ReviewColor {
    GRAY,
    PINK,
    YELLOW,
    PURPLE,
    BLUE
}